export default {
  ALL_TODOS: '/all',
  ACTIVE_TODOS: '/active',
  COMPLETED_TODOS: '/completed',
};
