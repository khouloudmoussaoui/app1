import React from 'react';
import TodoList from './todoList';

export default function AllTodos(props) {
  return <TodoList {...props} />;
}
