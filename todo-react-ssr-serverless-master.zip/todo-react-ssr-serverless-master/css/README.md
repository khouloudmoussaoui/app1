The following files in this directory were taken from TodoMVC project:

 - base.css
 - index.css

https://github.com/tastejs/todomvc

Following files are taken from http://tobiasahlin.com/spinkit/

 - spinner.css
