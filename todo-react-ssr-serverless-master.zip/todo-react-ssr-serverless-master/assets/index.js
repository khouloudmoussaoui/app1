import logo from './logo.png';
export const Logo = logo;

